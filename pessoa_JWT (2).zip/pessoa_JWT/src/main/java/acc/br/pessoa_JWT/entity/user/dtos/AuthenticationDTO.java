package acc.br.pessoa_JWT.entity.user.dtos;



public record AuthenticationDTO(String login, String password) {



}

