package acc.br.pessoa_JWT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PessoaJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PessoaJwtApplication.class, args);
	}

}
