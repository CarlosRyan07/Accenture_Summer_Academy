package acc.br.pessoa_JWT.entity.user.dtos;



public record LoginResponseDTO(String token) {



}

