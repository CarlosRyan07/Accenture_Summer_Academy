package acc.br.pessoa_JWT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoaJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
